CloudFront domain name 

d2btgahafmn68c.cloudfront.net

website-endpoint

http://my-993981366847-bucket.s3-website-us-east-1.amazonaws.com

 A URL to Access the bucket object via its S3 object
 
https://my-993981366847-bucket.s3.amazonaws.com/index.html


*********************************************************************************

Udacity Cloud Developer Nano Degree
Abebe Woldetsadik
abebewoldetsadik@gmail.com

**********************************************************************************
